// commander.d.ts
declare module "commander" {
	export * from "@commander-js/extra-typings"
}
