curl -L https://github.com/yt-dlp/yt-dlp-nightly-builds/releases/latest/download/yt-dlp -o yt-dlp && chmod +x ./yt-dlp && sudo mv yt-dlp /usr/local/bin/yt-dlp

pip install ruff autopep8
